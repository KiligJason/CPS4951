@extends('template')
@section('conteudo')
    <div class="container">
        <div class="row">
            <a class="waves-effect waves-light btn mb-4 green lighten-2" href="{{route('refrigerator.create')}}">
                <i class="material-icons right">add</i>Add food
            </a>
        </div>
        <table class="responsive-table  highlight">
            @forelse($foods as $food)
                <tr>
                    <td>{{$food->name}} (Notificação no dia: {{\Carbon\Carbon::parse($food->pivot->expiration_date)->format('d/m/Y')}})</td>
                    <td>
                        <a href="{{route('refrigerator.edit', ['foodId' => $food->id])}}" class="btn">Edit</a>
                    </td>
                </tr>
            @empty
                <div class="col s12 m12">
                    <div class="card-panel red lighten-2">
                        <span class="white-text">
                            If you don't have food or you need to change the validity data to the foods that you already have,
                            in both cases select add food and enter a validity date greater than the current day.
                        </span>
                    </div>
                </div>
            @endforelse
        </table>
    </div>
@endsection
