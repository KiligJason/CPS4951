@extends('template')

@section('conteudo')
    <div class="container">
        <div class="row">
            <h2>New food</h2>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="row">
            <form action="{{route('refrigerator.store')}}" method="POST">
                @csrf
                <label for="alimentos">What food are you saving?
                    <select name="food" id="alimentos" required>
                        <option value="{{$food->id}}" selected>{{$food->name}}</option>
                    </select>
                </label>
                <label for="quantidade">Quantity
                    <input type="number" name="quantity" value="{{$food->pivot->quantity}}" min="0" max="100">
                </label>
                <label for="validade">Validity
                    <input type="date" name="expiration_date"
                           value="{{\Carbon\Carbon::parse($food->pivot->expiration_date)->format('d/m/Y')}}">
                </label>
                <label for="notificacao">Notify how many days before expiration
                    <input type="number" name="notification" value="{{$food->pivot->notification}}" min="0">
                </label>
                <button class="btn full-width">Edit</button>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function () {
            $('#refeicao').formSelect();
            $('#alimentos').formSelect();
            $('.tabs').tabs();
            setTimeout(() => {
                $("#alimentos").trigger('contentChanged');
            }, 20)
        });
        $('#alimentos').on('contentChanged', function () {
            $(this).formSelect();
        });
    </script>
@endsection
