@extends("template")

@section("conteudo")
    <div class="row">
        <section class="col s12 m4">
            <form action="#" id="adicionaAlimento">
                <div class="input-field col s12">
                    <select name="refeicao" id="refeicao" required>
                        <option value="cafeDaManha" selected>Breakfast</option>
                        <option value="almoco">Lunch</option>
                        <option value="cafeDaTarde">Afternoon Tea</option>
                        <option value="jantar">Dinner</option>
                    </select>
                    <label for="refeicao">In which =meal do you want to add?</label>
                </div>

                <div class="input-field col s12">
                    <select name="alimento" id="alimentos" required>
                    </select>
                    <label for="alimentos">What food did you eat?</label>
                </div>
                <div class="input-field col s12">
                    <input id="quantidade" type="number" name="quantidade" step="1" min="1" max="100">
                    <label for="quantidade">Quantity in units</label>
                </div>
                <button class="btn" type="submit">ADD</button>
            </form>
        </section>


        <div class="col s12 m8">
            <button id="insertIngestedFoods" class="btn right">Save</button>
            <br><br>
            <ul class="tabs">
                <li class="tab col s3"><a class="active" href="#cafeDaManha">Breakfast</a></li>
                <li class="tab col s3"><a href="#almoco">Lunch</a></li>
                <li class="tab col s3"><a href="#cafeDaTarde">Afternoon tea</a></li>
                <li class="tab col s3"><a href="#jantar">Dinner</a></li>
            </ul>

            <div class="row" id="cafeDaManha">
                <table class="centered col s12" id="tabela-cafeDaManha">
                    <thead>
                    <tr>
                        <th colspan="2">Breakfast</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div class="row" id="almoco">
                <table class="centered col s12" id="tabela-almoco">
                    <thead>
                    <tr>
                        <th colspan="2">Lunch</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div class="row" id="cafeDaTarde">
                <table class="centered col s12" id="tabela-cafeDaTarde">
                    <thead>
                    <tr>
                        <th colspan="2">Afternoon Tea</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div class="row" id="jantar">
                <table class="centered col s12" id="tabela-jantar">
                    <thead>
                    <tr>
                        <th colspan="2">Dinner</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@section("scripts")
    <script>const id = {{__($id)}};</script>
    <script src="{{asset('js/HttpClient.js')}}"></script>
    <script src="{{asset('js/ingested-food/initializeFields.js')}}"></script>
    <script src="{{asset('js/ingested-food/TableManager.js')}}"></script>
    <script src="{{asset('js/ingested-food/initializeInsertButton.js')}}"></script>
    <script src="{{asset('js/ingested-food/searchFoods.js')}}"></script>
    <script src="{{asset('js/ingested-food/getFieldValues.js')}}"></script>
    <script src="{{asset('js/ingested-food/insertIngestedFoods.js')}}"></script>
@endsection
