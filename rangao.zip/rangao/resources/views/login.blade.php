@extends('template')
@section('conteudo')
    <div class="wallpaper">
        <main class="container">
            <div class="row centered-content">
                <h1>Diet!</h1>
                <div class="card-panel">
                    <form action="/login" method="post">
                        @csrf
                        @error('incorreto')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror

                        @error('email')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <label for="nome">Email
                            <input type="email" name="email" id="email" placeholder="2872729243@qq.com" required>
                        </label>

                        @error('senha')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <label for="senha">password
                            <input type="password" name="password" id="password" placeholder="*******" required>
                        </label>

                        <button class="btn full-width">LOGIN</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
@endsection
