@extends('template')

@section('conteudo')
    <main class="container">
        <form action="{{route('users.update', $user->id)}}" method="post" enctype="multipart/form-data">
            @method("put")
            @csrf
            <div class="file-field input-field">
                <div class="btn">
                    <span>File</span>
                    <input type="file" name="photo"/>
                </div>
                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text"/>
                </div>
            </div>
            @error('name')
            <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            <div class="row">
                <div class="input-field col s6">
                    <input placeholder="João da Silva" id="name" type="text" class="validate" name="name"
                           value="{{$user->name ? $user->name : ''}}"
                           required>
                    <label for="first_name">Name</label>
                </div>

                @error('email')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <input placeholder="{{$user->email ? $user->email : ''}}" id="email" type="email" class="validate"
                           name="email"
                           required disabled>
                    <label for="email">Email</label>
                </div>
            </div>

            <div class="row">
                @error('weight')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <input placeholder="65" id="weight" type="text" class="validate" name="weight"
                           value="{{$user->weight}}"

                           required>
                    <label for="weight">Weight</label>
                </div>

                @error('height')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <input placeholder="1.65" id="height" type="text" class="validate"
                           name="height" value="{{$user->height}}"
                           required>
                    <label for="height">Height</label>
                </div>
            </div>

            <div class="row">

                @error('birthday')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <input id="birthday" type="date" class="validate"
                           name="birthday" placeholder="{{$user->birthday}}"
                           required>
                    <label for="birthday">Birthday</label>
                </div>

                @error('gender')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <select name="gender" id="gender" disabled>
                        <option value="male" {{$user->gender === 'male' ? 'selected' :''}}>Male</option>
                        <option value="female" {{$user->gender === 'female' ? 'selected' :''}}>Female</option>
                    </select>
                    <label for="gender">Gender</label>
                </div>
                <input type="hidden" name="gender" value="{{$user->gender}}">
            </div>

            <div class="row">
                @error('objective')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <select name="objective" id="objective" required>
                        <option value="lose" {{$user->objective === 'lose' ? 'selected' :''}}>Lose weight</option>
                        <option value="define" {{$user->objective === 'define' ? 'selected' :''}}>Shape
                        </option>
                        <option value="gain" {{$user->objective === 'gain' ? 'selected' :''}}>Gain muscle</option>
                    </select>
                    <label for="objective">Objective</label>
                </div>


                @error('activity')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="input-field col s6">
                    <select name="activity" id="activity" required>
                        <option value="sedentary" {{$user->activity === 'sedentary' ? 'selected' :''}}>sedentary
                        </option>
                        <option value="littleActive" {{$user->activity === 'littleActive' ? 'selected' :''}}>littleActive
                            baixa
                        </option>
                        <option value="active" {{$user->activity === 'active' ? 'selected' :''}}>Active</option>
                        <option value="veryActive" {{$user->activity === 'veryActive' ? 'selected' :''}}>Veryactive
                        </option>
                    </select>
                    <label for="activity">Activity Level</label>
                </div>
            </div>
            <button class="btn full-width">Save</button>
        </form>
    </main>
@endsection

@section("scripts")
    <script>
        $(document).ready(function () {
            $('#activity').formSelect();
            $('#objective').formSelect();
            $('#gender').formSelect();

            $('#activity').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#objective').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#gender').on('contentChanged', function () {
                $(this).formSelect();
            });
        });
    </script>
@endsection
