@extends('template')

@section('conteudo')
    <div class="wallpaper">
        <main class="container">
            <div class="centered-content">
                <div class="card-panel">
                    <form action="{{route('users.store')}}" method="POST">
                        @csrf
                        @error('name')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <div class="row">
                            <div class="input-field col s6">
                                <input placeholder="Monica" id="name" type="text" class="validate" name="name"
                                       required>
                                <label for="first_name">Name</label>
                            </div>

                            @error('email')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <input placeholder="id@wku.edu.cn" id="email" type="email" class="validate"
                                       name="email"
                                       required>
                                <label for="email">Email</label>
                            </div>
                        </div>

                        @error('password')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <div class="row">
                            <div class="input-field col s12">
                                <input placeholder="********" id="password" type="password" class="validate"
                                       name="password"
                                       required>
                                <label for="password">password</label>
                            </div>
                        </div>

                        <div class="row">
                            @error('weight')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <input placeholder="65" id="weight" type="text" class="validate"
                                       name="weight"
                                       required>
                                <label for="weight">Weight</label>
                            </div>

                            @error('height')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <input placeholder="1.65" id="height" type="text" class="validate"
                                       name="height"
                                       required>
                                <label for="height">Height</label>
                            </div>
                        </div>

                        <div class="row">

                            @error('birthday')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <input id="birthday" type="date" class="validate"
                                       name="birthday"
                                       required>
                                <label for="birthday">Birthday</label>
                            </div>

                            @error('gender')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <select name="gender" id="gender" required>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <label for="gender">Gender</label>
                            </div>

                        </div>

                        <div class="row">
                            @error('objective')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <select name="objective" id="objective" required>
                                    <option value="lose">Lose weight</option>
                                    <option value="define">Shape</option>
                                    <option value="gain">Gain muscle</option>
                                </select>
                                <label for="objective">Objective</label>
                            </div>


                            @error('activity')
                            <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                            <div class="input-field col s6">
                                <select name="activity" id="activity" required>
                                    <option value="sedentary">sedentary</option>
                                    <option value="littleActive">littleActive</option>
                                    <option value="active">active</option>
                                    <option value="veryActive">veryActive</option>
                                </select>
                                <label for="activity">activity level</label>
                            </div>
                        </div>
                        <button class="btn full-width">REGISTER</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
@endsection
@section("scripts")
    <script>
        $(document).ready(function () {
            $('#activity').formSelect();
            $('#objective').formSelect();
            $('#gender').formSelect();

            $('#activity').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#objective').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#gender').on('contentChanged', function () {
                $(this).formSelect();
            });
        });
    </script>
@endsection
