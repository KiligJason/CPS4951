<?php $__env->startSection('conteudo'); ?>
    <main class="container">
        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field("put"); ?>
            <?php echo csrf_field(); ?>
            <div class="file-field input-field">
                <div class="btn">
                    <span>File</span>
                    <input type="file" name="photo"/>
                </div>
                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text"/>
                </div>
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="row">
                <div class="input-field col s6">
                    <input placeholder="João da Silva" id="name" type="text" class="validate" name="name"
                           value="<?php echo e($user->name ? $user->name : ''); ?>"
                           required>
                    <label for="first_name">Nome</label>
                </div>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <input placeholder="<?php echo e($user->email ? $user->email : ''); ?>" id="email" type="email" class="validate"
                           name="email"
                           required disabled>
                    <label for="email">Email</label>
                </div>
            </div>

            <div class="row">
                <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <input placeholder="65" id="weight" type="text" class="validate" name="weight"
                           value="<?php echo e($user->weight); ?>"

                           required>
                    <label for="weight">Peso</label>
                </div>

                <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <input placeholder="1.65" id="height" type="text" class="validate"
                           name="height" value="<?php echo e($user->height); ?>"
                           required>
                    <label for="height">Altura</label>
                </div>
            </div>

            <div class="row">

                <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <input id="birthday" type="date" class="validate"
                           name="birthday" placeholder="<?php echo e($user->birthday); ?>"
                           required>
                    <label for="birthday">Nascimento</label>
                </div>

                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <select name="gender" id="gender" disabled>
                        <option value="male" <?php echo e($user->gender === 'male' ? 'selected' :''); ?>>Masculino</option>
                        <option value="female" <?php echo e($user->gender === 'female' ? 'selected' :''); ?>>Feminino</option>
                    </select>
                    <label for="gender">Sexo biológico</label>
                </div>
                <input type="hidden" name="gender" value="<?php echo e($user->gender); ?>">
            </div>

            <div class="row">
                <?php $__errorArgs = ['objective'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <select name="objective" id="objective" required>
                        <option value="lose" <?php echo e($user->objective === 'lose' ? 'selected' :''); ?>>Perder peso</option>
                        <option value="define" <?php echo e($user->objective === 'define' ? 'selected' :''); ?>>Definir músculo
                        </option>
                        <option value="gain" <?php echo e($user->objective === 'gain' ? 'selected' :''); ?>>Ganhar Massa</option>
                    </select>
                    <label for="objective">Objetivo</label>
                </div>


                <?php $__errorArgs = ['activity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-field col s6">
                    <select name="activity" id="activity" required>
                        <option value="sedentary" <?php echo e($user->activity === 'sedentary' ? 'selected' :''); ?>>Sedentário
                        </option>
                        <option value="littleActive" <?php echo e($user->activity === 'littleActive' ? 'selected' :''); ?>>Atividade
                            baixa
                        </option>
                        <option value="active" <?php echo e($user->activity === 'active' ? 'selected' :''); ?>>Ativo</option>
                        <option value="veryActive" <?php echo e($user->activity === 'veryActive' ? 'selected' :''); ?>>Muito ativo
                        </option>
                    </select>
                    <label for="activity">Nível de atividade</label>
                </div>
            </div>
            <button class="btn full-width">Salvar</button>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script>
        $(document).ready(function () {
            $('#activity').formSelect();
            $('#objective').formSelect();
            $('#gender').formSelect();

            $('#activity').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#objective').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#gender').on('contentChanged', function () {
                $(this).formSelect();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/douwanying/Desktop/rangao/resources/views/users/edit.blade.php ENDPATH**/ ?>
