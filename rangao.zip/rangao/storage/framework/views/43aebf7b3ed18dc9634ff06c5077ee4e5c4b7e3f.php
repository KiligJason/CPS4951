<?php $__env->startSection("conteudo"); ?>
    <main class="container">
        <div class="row">
            <section class="col s12 m3">
                <img class="img user__photo" src="<?php echo e(Illuminate\Support\Facades\Storage::url($user->photo)); ?>"
                     alt="<?php echo e($user->name); ?>"/>
                <h5 class="center"><?php echo e($user->name); ?></h5>
                <br>
                <a class="waves-effect waves-light btn right full-width mb-4"
                   href="<?php echo e(route('users.edit', ['user' => \Illuminate\Support\Facades\Auth::id()])); ?>"><i
                        class="material-icons right">add</i>Ver mais</a>
            </section>
            <section class="col s12 m9">
                <div style="display: flex">






                    <a class="waves-effect waves-light btn mb-4" href="<?php echo e(route('meal.create')); ?>"><i
                            class="material-icons right">add</i>Refeições</a>
                </div>
                <table class="striped centered">
                    <thead>
                    <tr>
                        <th>Café da Manhã</th>
                        <th>Almoço</th>
                        <th>Café da tarde</th>
                        <th>Jantar</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php for($i = 0; $i < $rows; $i++): ?>
                        <tr>
                            <?php $__currentLoopData = $ingested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refeicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(array_key_exists($i, $refeicao)): ?>
                                    <td><?php echo e($refeicao[$i]->name); ?></td>
                                <?php else: ?>
                                    <td></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/douwanying/Desktop/rangao/resources/views/users/profile.blade.php ENDPATH**/ ?>
