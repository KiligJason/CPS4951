<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/recipe/recipes-all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <main class="content">
        <ul id="js-categoryList" class="category__list">
            <li class="category__item category__item--active">CATEGORY</li>
            <?php $__currentLoopData = $recipeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="category__item"><?php echo e($category->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php $__currentLoopData = $recipeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card__container js-results">
                <h4 class="category__name"><?php echo e($category->name); ?></h4>
                <?php $__currentLoopData = $category->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="recipe__card" href="<?php echo e(route('recipe.show', ['recipe'=> $recipe->id])); ?>">
                        <div class="recipe__header">
                            <img class="recipe__image"
                                 src="<?php echo e($recipe->photo); ?>" width="300" height="300"
                                 alt="<?php echo e($recipe->name); ?>">
                            <span class="recipe__title"><?php echo e($recipe->name); ?></span>
                        </div>
                        <div class="recipe__body">
                            <div class="recipe__calories"><?php echo e($recipe->calories); ?> Kcal</div>
                            <div class="recipe__time"><?php echo e($recipe->timeToPrepare); ?> Time</div>
                            <div class="recipe__difficulty"><?php echo e($recipe->difficulty); ?></div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/HttpClient.js')); ?>"></script>
    <script src="<?php echo e(asset('js/recipe/filterRecipes.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/douwanying/Desktop/rangao/resources/views/recipe/index.blade.php ENDPATH**/ ?>