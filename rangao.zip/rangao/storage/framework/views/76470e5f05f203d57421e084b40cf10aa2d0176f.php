<?php $__env->startSection('conteudo'); ?>
    <div class="wallpaper">
        <main class="container">
            <div class="centered-content">
                <div class="card-panel">
                    <form action="<?php echo e(route('users.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="row">
                            <div class="input-field col s6">
                                <input placeholder="Monica" id="name" type="text" class="validate" name="name"
                                       required>
                                <label for="first_name">Name</label>
                            </div>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <input placeholder="id@wku.edu.cn" id="email" type="email" class="validate"
                                       name="email"
                                       required>
                                <label for="email">Email</label>
                            </div>
                        </div>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="row">
                            <div class="input-field col s12">
                                <input placeholder="********" id="password" type="password" class="validate"
                                       name="password"
                                       required>
                                <label for="password">password</label>
                            </div>
                        </div>

                        <div class="row">
                            <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <input placeholder="65" id="weight" type="text" class="validate"
                                       name="weight"
                                       required>
                                <label for="weight">Weight</label>
                            </div>

                            <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <input placeholder="1.65" id="height" type="text" class="validate"
                                       name="height"
                                       required>
                                <label for="height">Height</label>
                            </div>
                        </div>

                        <div class="row">

                            <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <input id="birthday" type="date" class="validate"
                                       name="birthday"
                                       required>
                                <label for="birthday">Birthday</label>
                            </div>

                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <select name="gender" id="gender" required>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <label for="gender">Gender</label>
                            </div>

                        </div>

                        <div class="row">
                            <?php $__errorArgs = ['objective'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <select name="objective" id="objective" required>
                                    <option value="lose">Lose weight</option>
                                    <option value="define">Shape</option>
                                    <option value="gain">Gain muscle</option>
                                </select>
                                <label for="objective">Objective</label>
                            </div>


                            <?php $__errorArgs = ['activity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="input-field col s6">
                                <select name="activity" id="activity" required>
                                    <option value="sedentary">sedentary</option>
                                    <option value="littleActive">littleActive</option>
                                    <option value="active">active</option>
                                    <option value="veryActive">veryActive</option>
                                </select>
                                <label for="activity">activity level</label>
                            </div>
                        </div>
                        <button class="btn full-width">REGISTER</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>
    <script>
        $(document).ready(function () {
            $('#activity').formSelect();
            $('#objective').formSelect();
            $('#gender').formSelect();

            $('#activity').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#objective').on('contentChanged', function () {
                $(this).formSelect();
            });

            $('#gender').on('contentChanged', function () {
                $(this).formSelect();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/douwanying/Desktop/rangao/resources/views/users/create.blade.php ENDPATH**/ ?>