# Rangão!

Seja bem vindo ao rangão, o pet project desse que vos fala. Para rodar ele é bem simples: O primeiro passo é clonar o repositório

```git
git clone git@github.com:DevCapu/rangao.git
```

Após clonar entre na pasta do projeto

```git
cd rangao
```
E rode o comando
```composer log
composer install
```
 Esse parte de cima pode demorar um pouco, pois ele irá instalar todas as dependências.
 
 Após finalizado rode o comando:
 
```
php artisan serve
```

e entre na url do servidor (que por padrão será http://localhost:8000/)

#TODO 
 * Um usuário só pode editar o próprio perfil
