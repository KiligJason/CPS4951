package com.milotnt.service;

import com.milotnt.pojo.Admin;



public interface AdminService {

    //管理员登录
    Admin adminLogin(Admin admin);

}
